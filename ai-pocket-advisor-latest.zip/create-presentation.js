const pptxgen = require("pptxgenjs");

let pres = new pptxgen();
pres.layout = 'LAYOUT_16x9';
pres.author = 'Luyu Meng';
pres.title = 'AI Pocket Advisor - Agentic AI for FinTech';

// Color palette - FinTech style
const colors = {
  navy: "1E2761",
  darkBlue: "141B4D",
  cyan: "00D4FF",
  white: "FFFFFF",
  lightGray: "E8E8E8",
  textGray: "CCCCCC",
  accent: "00D4FF",
  cardBg: "243378"
};

// Helper: create shadow config fresh each time
const makeShadow = () => ({ type: "outer", blur: 8, offset: 3, angle: 135, color: "000000", opacity: 0.25 });

// ================== SLIDE 1: Title Slide ==================
let slide1 = pres.addSlide();
slide1.background = { color: colors.navy };

// Decorative top bar
slide1.addShape(pres.shapes.RECTANGLE, {
  x: 0, y: 0, w: 10, h: 0.15, fill: { color: colors.cyan }
});

// Main title
slide1.addText("Agentic AI for FinTech and Business Application", {
  x: 0.5, y: 1.8, w: 9, h: 0.8,
  fontSize: 32, fontFace: "Arial", color: colors.white, bold: true, align: "center"
});

// Subtitle
slide1.addText("AI Pocket Advisor", {
  x: 0.5, y: 2.7, w: 9, h: 0.6,
  fontSize: 44, fontFace: "Arial", color: colors.cyan, bold: true, align: "center"
});

slide1.addText("A Personal Wealth and Investment Planning Assistant", {
  x: 0.5, y: 3.3, w: 9, h: 0.5,
  fontSize: 20, fontFace: "Arial", color: colors.textGray, align: "center"
});

// Course info
slide1.addShape(pres.shapes.RECTANGLE, {
  x: 2.5, y: 4.3, w: 5, h: 0.9, fill: { color: colors.cardBg }, shadow: makeShadow()
});
slide1.addText([
  { text: "HKU SPACE\n", options: { fontSize: 14, breakLine: true } },
  { text: "Agentic AI for FinTech", options: { fontSize: 12, color: colors.textGray } }
], {
  x: 2.5, y: 4.4, w: 2.3, h: 0.8, align: "center", valign: "middle"
});
slide1.addText([
  { text: "Instructor\n", options: { fontSize: 14, breakLine: true } },
  { text: "[Instructor Name]", options: { fontSize: 12, color: colors.textGray } }
], {
  x: 5, y: 4.4, w: 2.25, h: 0.8, align: "center", valign: "middle"
});
slide1.addText([
  { text: "Date\n", options: { fontSize: 14, breakLine: true } },
  { text: "August 2026", options: { fontSize: 12, color: colors.textGray } }
], {
  x: 7.5, y: 4.4, w: 2, h: 0.8, align: "center", valign: "middle"
});

// ================== SLIDE 2: Project Overview ==================
let slide2 = pres.addSlide();
slide2.background = { color: colors.lightGray };

slide2.addText("What is AI Pocket Advisor?", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

// Main content card
slide2.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.1, w: 9, h: 3.8, fill: { color: colors.white }, shadow: makeShadow()
});

// Accent bar
slide2.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.1, w: 0.1, h: 3.8, fill: { color: colors.cyan }
});

slide2.addText("AI Pocket Advisor is a web-based personal finance and wealth planning platform that helps users:", {
  x: 0.8, y: 1.3, w: 8.5, h: 0.5, fontSize: 16, fontFace: "Arial", color: colors.navy, bold: true
});

// Feature bullets
slide2.addText([
  { text: "Complete a wealth onboarding survey", options: { bullet: true, breakLine: true } },
  { text: "Track income and expenditures", options: { bullet: true, breakLine: true } },
  { text: "Analyze real estate assets", options: { bullet: true, breakLine: true } },
  { text: "Review stock market information", options: { bullet: true, breakLine: true } },
  { text: "Understand their portfolio composition", options: { bullet: true, breakLine: true } },
  { text: "Receive AI-assisted, educational financial recommendations", options: { bullet: true } }
], {
  x: 0.8, y: 1.9, w: 8.5, h: 2.2, fontSize: 14, fontFace: "Arial", color: "444444", paraSpaceAfter: 8
});

// Key positioning
slide2.addShape(pres.shapes.RECTANGLE, {
  x: 0.8, y: 4.2, w: 8.4, h: 0.5, fill: { color: colors.navy }
});
slide2.addText("The platform is designed as an educational personal finance assistant, not a guaranteed investment advisor.", {
  x: 0.8, y: 4.2, w: 8.4, h: 0.5, fontSize: 13, fontFace: "Arial", color: colors.white, align: "center", valign: "middle"
});

// ================== SLIDE 3: Problem Statement ==================
let slide3 = pres.addSlide();
slide3.background = { color: colors.lightGray };

slide3.addText("The Financial Decision-Making Problem", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

// Problem cards - 2x3 grid
const problems = [
  "Fragmented financial information",
  "Lack of understanding of their risk profile",
  "Difficulty comparing real estate, stocks, and cashflow",
  "Poor expenditure visibility",
  "Emotional or uninformed investment decisions",
  "Limited access to personalized financial planning support"
];

const cardW = 2.8, cardH = 1.1;
const startX = 0.6, startY = 1.2, gapX = 0.2, gapY = 0.15;

problems.forEach((prob, i) => {
  const col = i % 3;
  const row = Math.floor(i / 3);
  const x = startX + col * (cardW + gapX);
  const y = startY + row * (cardH + gapY);

  slide3.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: cardW, h: cardH, fill: { color: colors.white }, shadow: makeShadow()
  });
  slide3.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: 0.08, h: cardH, fill: { color: colors.cyan }
  });
  slide3.addText(prob, {
    x: x + 0.2, y: y, w: cardW - 0.3, h: cardH, fontSize: 12, fontFace: "Arial", color: "444444", valign: "middle"
  });
});

// Main problem statement
slide3.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 4.5, w: 9, h: 0.9, fill: { color: colors.navy }
});
slide3.addText("Main Problem: Individuals often have financial data, but they lack a structured system to transform that data into clear, personalized, and responsible financial insights.", {
  x: 0.7, y: 4.5, w: 8.6, h: 0.9, fontSize: 14, fontFace: "Arial", color: colors.white, valign: "middle", align: "center"
});

// ================== SLIDE 4: Why Agentic AI ==================
let slide4 = pres.addSlide();
slide4.background = { color: colors.lightGray };

slide4.addText("Why Use Agentic AI in FinTech?", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

// Definition card
slide4.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.1, w: 9, h: 1.0, fill: { color: colors.navy }
});
slide4.addText("Agentic AI Definition", {
  x: 0.7, y: 1.15, w: 8.6, h: 0.35, fontSize: 14, fontFace: "Arial", color: colors.cyan, bold: true
});
slide4.addText("AI systems that perform goal-oriented tasks by planning, reasoning, using tools/data sources, and taking multi-step actions to support users.", {
  x: 0.7, y: 1.5, w: 8.6, h: 0.5, fontSize: 13, fontFace: "Arial", color: colors.white
});

// How AI goes beyond traditional
slide4.addText("Agentic AI vs Traditional Finance Apps:", {
  x: 0.5, y: 2.3, w: 9, h: 0.4, fontSize: 16, fontFace: "Arial", color: colors.navy, bold: true
});

const aiBenefits = [
  { title: "Understanding User Goals", desc: "Learns personal financial objectives" },
  { title: "Collecting Context", desc: "Gathers relevant financial data" },
  { title: "Analyzing Multiple Areas", desc: "Evaluates investments comprehensively" },
  { title: "Generating Recommendations", desc: "Provides personalized suggestions" },
  { title: "Updating Dynamically", desc: "Adapts when new info appears" },
  { title: "Explaining Reasoning", desc: "Human-friendly explanations" }
];

aiBenefits.forEach((item, i) => {
  const col = i % 3;
  const row = Math.floor(i / 3);
  const x = 0.5 + col * 3;
  const y = 2.75 + row * 1.3;

  slide4.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: 2.8, h: 1.1, fill: { color: colors.white }, shadow: makeShadow()
  });
  slide4.addText(item.title, {
    x: x + 0.15, y: y + 0.15, w: 2.5, h: 0.4, fontSize: 13, fontFace: "Arial", color: colors.navy, bold: true
  });
  slide4.addText(item.desc, {
    x: x + 0.15, y: y + 0.55, w: 2.5, h: 0.4, fontSize: 11, fontFace: "Arial", color: "666666"
  });
});

// ================== SLIDE 5: Target Users ==================
let slide5 = pres.addSlide();
slide5.background = { color: colors.lightGray };

slide5.addText("Target Users and Value Proposition", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

// Target users - left side
slide5.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.1, w: 4.3, h: 4.2, fill: { color: colors.white }, shadow: makeShadow()
});
slide5.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.1, w: 4.3, h: 0.5, fill: { color: colors.navy }
});
slide5.addText("Target Users", {
  x: 0.5, y: 1.1, w: 4.3, h: 0.5, fontSize: 16, fontFace: "Arial", color: colors.white, bold: true, align: "center", valign: "middle"
});

const users = [
  "Young professionals",
  "Beginner investors",
  "Users who own or plan to own property",
  "Users who want clearer view of spending and wealth",
  "Users interested in stocks and portfolio planning"
];

slide5.addText(users.map((u, i) => ({
  text: u,
  options: { bullet: true, breakLine: i < users.length - 1 }
})), {
  x: 0.7, y: 1.75, w: 3.9, h: 3.3, fontSize: 13, fontFace: "Arial", color: "444444", paraSpaceAfter: 10
});

// Business value - right side
slide5.addShape(pres.shapes.RECTANGLE, {
  x: 5.2, y: 1.1, w: 4.3, h: 4.2, fill: { color: colors.white }, shadow: makeShadow()
});
slide5.addShape(pres.shapes.RECTANGLE, {
  x: 5.2, y: 1.1, w: 4.3, h: 0.5, fill: { color: colors.cyan }
});
slide5.addText("Business Value", {
  x: 5.2, y: 1.1, w: 4.3, h: 0.5, fontSize: 16, fontFace: "Arial", color: colors.navy, bold: true, align: "center", valign: "middle"
});

slide5.addText("For Users:", {
  x: 5.4, y: 1.75, w: 3.9, h: 0.35, fontSize: 13, fontFace: "Arial", color: colors.navy, bold: true
});
slide5.addText([
  { text: "Easier financial self-assessment", options: { bullet: true, breakLine: true } },
  { text: "Better visibility of assets and liabilities", options: { bullet: true, breakLine: true } },
  { text: "More structured investment thinking", options: { bullet: true, breakLine: true } },
  { text: "Educational support", options: { bullet: true } }
], {
  x: 5.4, y: 2.1, w: 3.9, h: 1.5, fontSize: 11, fontFace: "Arial", color: "444444", paraSpaceAfter: 6
});

slide5.addText("For Business:", {
  x: 5.4, y: 3.5, w: 3.9, h: 0.35, fontSize: 13, fontFace: "Arial", color: colors.navy, bold: true
});
slide5.addText([
  { text: "Scalable digital advisory experience", options: { bullet: true, breakLine: true } },
  { text: "Lower cost than traditional advisory", options: { bullet: true, breakLine: true } },
  { text: "Subscription/premium analytics potential", options: { bullet: true } }
], {
  x: 5.4, y: 3.85, w: 3.9, h: 1.2, fontSize: 11, fontFace: "Arial", color: "444444", paraSpaceAfter: 6
});

// ================== SLIDE 6: Feature Overview ==================
let slide6 = pres.addSlide();
slide6.background = { color: colors.lightGray };

slide6.addText("Core Features of the Website", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

// Feature table
const tableData = [
  [{ text: "Feature", options: { fill: { color: colors.navy }, color: colors.white, bold: true } },
   { text: "Purpose", options: { fill: { color: colors.navy }, color: colors.white, bold: true } }],
  [{ text: "Wealth Onboarding Survey", options: { fill: { color: colors.white } } },
   { text: "Understand user profile, goals, and risk tolerance", options: { fill: { color: colors.white } } }],
  [{ text: "Expenditures", options: { fill: { color: "F5F5F5" } } },
   { text: "Track spending behavior and cashflow", options: { fill: { color: "F5F5F5" } } }],
  [{ text: "Real Estate", options: { fill: { color: colors.white } } },
   { text: "Analyze property assets and opportunity candidates", options: { fill: { color: colors.white } } }],
  [{ text: "Stock Market Analysis", options: { fill: { color: "F5F5F5" } } },
   { text: "Support market awareness and stock-related insights", options: { fill: { color: "F5F5F5" } } }],
  [{ text: "User Portfolio", options: { fill: { color: colors.white } } },
   { text: "Show asset allocation and wealth overview", options: { fill: { color: colors.white } } }]
];

slide6.addTable(tableData, {
  x: 0.5, y: 1.1, w: 9, h: 3.2,
  colW: [3.5, 5.5],
  border: { pt: 0.5, color: "CCCCCC" },
  fontFace: "Arial",
  fontSize: 12,
  color: "333333",
  align: "left",
  valign: "middle"
});

// Speaker note box
slide6.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 4.5, w: 9, h: 0.85, fill: { color: colors.navy }
});
slide6.addText("The website combines multiple areas of personal finance into one financial decision-making environment.", {
  x: 0.7, y: 4.5, w: 8.6, h: 0.85, fontSize: 14, fontFace: "Arial", color: colors.white, valign: "middle", align: "center"
});

// ================== SLIDE 7: Wealth Onboarding ==================
let slide7 = pres.addSlide();
slide7.background = { color: colors.lightGray };

slide7.addText("Wealth Onboarding Survey", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

slide7.addText("Step 1: Understanding the User", {
  x: 0.5, y: 0.9, w: 9, h: 0.4, fontSize: 20, fontFace: "Arial", color: colors.cyan, bold: true
});

// Survey items
slide7.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.4, w: 5.5, h: 3.0, fill: { color: colors.white }, shadow: makeShadow()
});
slide7.addText("The onboarding survey collects:", {
  x: 0.7, y: 1.5, w: 5.1, h: 0.4, fontSize: 14, fontFace: "Arial", color: colors.navy, bold: true
});

const surveyItems = [
  "Financial goals",
  "Income range",
  "Investment experience",
  "Risk tolerance",
  "Time horizon",
  "Asset ownership",
  "Debt or financing preferences",
  "Rent/income goals (if real estate)"
];

slide7.addText(surveyItems.map((item, i) => ({
  text: item,
  options: { bullet: true, breakLine: i < surveyItems.length - 1 }
})), {
  x: 0.7, y: 1.95, w: 5.1, h: 2.3, fontSize: 12, fontFace: "Arial", color: "444444", paraSpaceAfter: 6
});

// Why it matters
slide7.addShape(pres.shapes.RECTANGLE, {
  x: 6.3, y: 1.4, w: 3.2, h: 1.3, fill: { color: colors.navy }
});
slide7.addText("Why It Matters", {
  x: 6.5, y: 1.5, w: 2.8, h: 0.35, fontSize: 14, fontFace: "Arial", color: colors.cyan, bold: true
});
slide7.addText("This is the foundation for personalization.", {
  x: 6.5, y: 1.9, w: 2.8, h: 0.6, fontSize: 12, fontFace: "Arial", color: colors.white
});

// AI role
slide7.addShape(pres.shapes.RECTANGLE, {
  x: 6.3, y: 2.9, w: 3.2, h: 1.5, fill: { color: colors.cardBg }
});
slide7.addText("Agentic AI Role", {
  x: 6.5, y: 3.0, w: 2.8, h: 0.35, fontSize: 14, fontFace: "Arial", color: colors.cyan, bold: true
});
slide7.addText("Determines user risk profile, goal priorities, suitable recommendation style, and areas needing attention.", {
  x: 6.5, y: 3.4, w: 2.8, h: 0.9, fontSize: 11, fontFace: "Arial", color: colors.white
});

// Flow diagram
slide7.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 4.55, w: 9, h: 0.8, fill: { color: colors.white }, shadow: makeShadow()
});
slide7.addText("User Survey", { x: 1.0, y: 4.7, w: 1.8, h: 0.5, fontSize: 12, fontFace: "Arial", color: colors.navy, bold: true, align: "center", valign: "middle" });
slide7.addText("→", { x: 2.8, y: 4.7, w: 0.5, h: 0.5, fontSize: 20, color: colors.cyan, align: "center", valign: "middle" });
slide7.addText("Risk Profile", { x: 3.3, y: 4.7, w: 1.8, h: 0.5, fontSize: 12, fontFace: "Arial", color: colors.navy, bold: true, align: "center", valign: "middle" });
slide7.addText("→", { x: 5.1, y: 4.7, w: 0.5, h: 0.5, fontSize: 20, color: colors.cyan, align: "center", valign: "middle" });
slide7.addText("Personalized Insights", { x: 5.6, y: 4.7, w: 2.5, h: 0.5, fontSize: 12, fontFace: "Arial", color: colors.navy, bold: true, align: "center", valign: "middle" });

// ================== SLIDE 8: Expenditure Analysis ==================
let slide8 = pres.addSlide();
slide8.background = { color: colors.lightGray };

slide8.addText("Expenditure and Cashflow Analysis", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

slide8.addText("Step 2: Understanding Spending Behavior", {
  x: 0.5, y: 0.9, w: 9, h: 0.4, fontSize: 20, fontFace: "Arial", color: colors.cyan, bold: true
});

// Features
const expenditureFeatures = [
  { title: "Monthly Spending Patterns", desc: "Track recurring vs one-time expenses" },
  { title: "Fixed vs Variable Costs", desc: "Distinguish essential vs discretionary spending" },
  { title: "Savings Potential", desc: "Identify areas for improvement" },
  { title: "Cashflow Pressure", desc: "Spot potential liquidity issues" },
  { title: "Budget Risks", desc: "Alert on overspending trends" }
];

expenditureFeatures.forEach((item, i) => {
  const col = i % 2;
  const row = Math.floor(i / 2);
  const x = 0.5 + col * 4.7;
  const y = 1.5 + row * 1.15;

  slide8.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: 4.4, h: 1.0, fill: { color: colors.white }, shadow: makeShadow()
  });
  slide8.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: 0.08, h: 1.0, fill: { color: colors.cyan }
  });
  slide8.addText(item.title, {
    x: x + 0.2, y: y + 0.1, w: 4.0, h: 0.35, fontSize: 13, fontFace: "Arial", color: colors.navy, bold: true
  });
  slide8.addText(item.desc, {
    x: x + 0.2, y: y + 0.5, w: 4.0, h: 0.4, fontSize: 11, fontFace: "Arial", color: "666666"
  });
});

// Why important
slide8.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 4.0, w: 9, h: 1.35, fill: { color: colors.navy }
});
slide8.addText("Why This Is Important in FinTech", {
  x: 0.7, y: 4.1, w: 8.6, h: 0.35, fontSize: 14, fontFace: "Arial", color: colors.cyan, bold: true
});
slide8.addText("Before giving investment recommendations, the system should understand whether the user has sufficient emergency savings, stable monthly surplus, high debt burden, or over-spending patterns.", {
  x: 0.7, y: 4.5, w: 8.6, h: 0.7, fontSize: 12, fontFace: "Arial", color: colors.white
});

// ================== SLIDE 9: Real Estate Module ==================
let slide9 = pres.addSlide();
slide9.background = { color: colors.lightGray };

slide9.addText("Real Estate Module", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

slide9.addText("Step 3: Real Estate Analysis and Opportunity Candidates", {
  x: 0.5, y: 0.9, w: 9, h: 0.4, fontSize: 20, fontFace: "Arial", color: colors.cyan, bold: true
});

// Features list
const reFeatures = [
  "Property ownership overview",
  "District + segment recommendations",
  "Rent-focused investment option",
  "User-provided vacancy assumptions",
  "Budget simulation with mortgage financing",
  "Interest-only mortgage support",
  "Debt capacity and payoff estimation"
];

slide9.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.4, w: 4.5, h: 2.6, fill: { color: colors.white }, shadow: makeShadow()
});
slide9.addText("Key Features:", {
  x: 0.7, y: 1.5, w: 4.1, h: 0.35, fontSize: 14, fontFace: "Arial", color: colors.navy, bold: true
});
slide9.addText(reFeatures.map((f, i) => ({
  text: f,
  options: { bullet: true, breakLine: i < reFeatures.length - 1 }
})), {
  x: 0.7, y: 1.9, w: 4.1, h: 2.0, fontSize: 11, fontFace: "Arial", color: "444444", paraSpaceAfter: 5
});

// Example & credit
slide9.addShape(pres.shapes.RECTANGLE, {
  x: 5.2, y: 1.4, w: 4.3, h: 1.2, fill: { color: colors.cardBg }
});
slide9.addText("Example Candidate:", {
  x: 5.4, y: 1.5, w: 3.9, h: 0.3, fontSize: 13, fontFace: "Arial", color: colors.cyan, bold: true
});
slide9.addText("Kowloon City / Residential / 300-600 sq ft / Rent-focused opportunity", {
  x: 5.4, y: 1.85, w: 3.9, h: 0.6, fontSize: 11, fontFace: "Arial", color: colors.white
});

slide9.addShape(pres.shapes.RECTANGLE, {
  x: 5.2, y: 2.75, w: 4.3, h: 1.2, fill: { color: colors.navy }
});
slide9.addText("Credit-Based Measurements:", {
  x: 5.4, y: 2.85, w: 3.9, h: 0.3, fontSize: 13, fontFace: "Arial", color: colors.cyan, bold: true
});
slide9.addText("Debt capacity, monthly payment estimates, debt-to-income ratio, cashflow coverage, repayment pathway", {
  x: 5.4, y: 3.2, w: 3.9, h: 0.6, fontSize: 10, fontFace: "Arial", color: colors.white
});

// Compliance
slide9.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 4.2, w: 9, h: 1.15, fill: { color: "FFF3E0" }, line: { color: "FF9800", pt: 1 }
});
slide9.addText("⚠ Compliance Point:", {
  x: 0.7, y: 4.3, w: 8.6, h: 0.35, fontSize: 14, fontFace: "Arial", color: "E65100", bold: true
});
slide9.addText("The system should avoid saying \"buy this property.\" Instead, it recommends opportunity areas or segments. All outputs are educational insights, not guaranteed investment advice.", {
  x: 0.7, y: 4.7, w: 8.6, h: 0.6, fontSize: 12, fontFace: "Arial", color: "444444"
});

// ================== SLIDE 10: Stock Market Analysis ==================
let slide10 = pres.addSlide();
slide10.background = { color: colors.lightGray };

slide10.addText("Stock Market Analysis", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

slide10.addText("Step 4: Stock Market and Investment Insights", {
  x: 0.5, y: 0.9, w: 9, h: 0.4, fontSize: 20, fontFace: "Arial", color: colors.cyan, bold: true
});

// Features
const stockFeatures = [
  { title: "Market Trends", desc: "Understand overall market direction" },
  { title: "Stock Performance", desc: "Track individual stock performance" },
  { title: "Risk & Volatility", desc: "Assess risk levels and volatility" },
  { title: "Sector Exposure", desc: "Analyze sector allocation" },
  { title: "Educational Analysis", desc: "Learn about investment concepts" }
];

stockFeatures.forEach((item, i) => {
  const col = i % 3;
  const row = Math.floor(i / 3);
  const x = 0.5 + col * 3.1;
  const y = 1.4 + row * 1.2;

  slide10.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: 2.9, h: 1.0, fill: { color: colors.white }, shadow: makeShadow()
  });
  slide10.addText(item.title, {
    x: x + 0.15, y: y + 0.1, w: 2.6, h: 0.35, fontSize: 13, fontFace: "Arial", color: colors.navy, bold: true
  });
  slide10.addText(item.desc, {
    x: x + 0.15, y: y + 0.5, w: 2.6, h: 0.4, fontSize: 11, fontFace: "Arial", color: "666666"
  });
});

// AI role
slide10.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 3.8, w: 4.4, h: 1.5, fill: { color: colors.navy }
});
slide10.addText("Agentic AI Role", {
  x: 0.7, y: 3.9, w: 4.0, h: 0.35, fontSize: 14, fontFace: "Arial", color: colors.cyan, bold: true
});
slide10.addText([
  { text: "Summarize market signals", options: { bullet: true, breakLine: true } },
  { text: "Compare stocks with user goals", options: { bullet: true, breakLine: true } },
  { text: "Explain risk factors", options: { bullet: true, breakLine: true } },
  { text: "Suggest watchlist ideas", options: { bullet: true, breakLine: true } },
  { text: "Warn when something doesn't fit profile", options: { bullet: true } }
], {
  x: 0.7, y: 4.3, w: 4.0, h: 1.0, fontSize: 10, fontFace: "Arial", color: colors.white, paraSpaceAfter: 3
});

// Compliance
slide10.addShape(pres.shapes.RECTANGLE, {
  x: 5.1, y: 3.8, w: 4.4, h: 1.5, fill: { color: colors.cardBg }
});
slide10.addText("⚠ Important Compliance", {
  x: 5.3, y: 3.9, w: 4.0, h: 0.35, fontSize: 14, fontFace: "Arial", color: "FFB74D", bold: true
});
slide10.addText("Stock-related outputs should be framed as educational insights, not guaranteed buy/sell instructions.", {
  x: 5.3, y: 4.3, w: 4.0, h: 0.9, fontSize: 12, fontFace: "Arial", color: colors.white
});

// ================== SLIDE 11: Portfolio Dashboard ==================
let slide11 = pres.addSlide();
slide11.background = { color: colors.lightGray };

slide11.addText("User Portfolio Dashboard", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

slide11.addText("Step 5: Portfolio View and Wealth Overview", {
  x: 0.5, y: 0.9, w: 9, h: 0.4, fontSize: 20, fontFace: "Arial", color: colors.cyan, bold: true
});

// Portfolio items
const portfolioItems = [
  { title: "Total Asset Value", desc: "Overall wealth calculation" },
  { title: "Asset Allocation", desc: "Cash / stocks / real estate / other" },
  { title: "Risk Exposure", desc: "Portfolio risk level assessment" },
  { title: "Concentration Risk", desc: "Avoid over-concentration" },
  { title: "Estimated Net Worth", desc: "Assets minus liabilities" },
  { title: "Changes Over Time", desc: "Track wealth progression" }
];

portfolioItems.forEach((item, i) => {
  const col = i % 3;
  const row = Math.floor(i / 3);
  const x = 0.5 + col * 3.1;
  const y = 1.4 + row * 1.25;

  slide11.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: 2.9, h: 1.1, fill: { color: colors.white }, shadow: makeShadow()
  });
  slide11.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: 2.9, h: 0.08, fill: { color: colors.cyan }
  });
  slide11.addText(item.title, {
    x: x + 0.15, y: y + 0.2, w: 2.6, h: 0.35, fontSize: 13, fontFace: "Arial", color: colors.navy, bold: true
  });
  slide11.addText(item.desc, {
    x: x + 0.15, y: y + 0.6, w: 2.6, h: 0.35, fontSize: 11, fontFace: "Arial", color: "666666"
  });
});

// Why matters
slide11.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 4.15, w: 9, h: 1.2, fill: { color: colors.navy }
});
slide11.addText("Why This Matters:", {
  x: 0.7, y: 4.25, w: 8.6, h: 0.35, fontSize: 14, fontFace: "Arial", color: colors.cyan, bold: true
});
slide11.addText("A portfolio view allows the user to see their whole financial picture, not just individual investments. Example insights: \"Your portfolio is highly concentrated in real estate.\" \"Your cash reserve may be low compared with monthly expenses.\"", {
  x: 0.7, y: 4.65, w: 8.6, h: 0.6, fontSize: 12, fontFace: "Arial", color: colors.white
});

// ================== SLIDE 12: AI Agent Workflow ==================
let slide12 = pres.addSlide();
slide12.background = { color: colors.lightGray };

slide12.addText("How the AI Agent Works", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

// Workflow diagram
const workflowSteps = [
  { num: "1", title: "User Inputs", desc: "Onboarding + Portfolio + Expenditure Data" },
  { num: "2", title: "AI Agent Reasoning", desc: "Analyzes financial position" },
  { num: "3", title: "External Data", desc: "Market data integration" },
  { num: "4", title: "Analysis", desc: "Risk, Cashflow, Real Estate, Stocks" },
  { num: "5", title: "Recommendations", desc: "Personalized educational insights" },
  { num: "6", title: "User Action", desc: "Simulate, Compare, Adjust, Learn" }
];

workflowSteps.forEach((step, i) => {
  const col = i % 3;
  const row = Math.floor(i / 3);
  const x = 0.5 + col * 3.1;
  const y = 1.1 + row * 1.6;

  slide12.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: 2.9, h: 1.4, fill: { color: colors.white }, shadow: makeShadow()
  });
  // Number circle
  slide12.addShape(pres.shapes.OVAL, {
    x: x + 0.15, y: y + 0.15, w: 0.45, h: 0.45, fill: { color: colors.cyan }
  });
  slide12.addText(step.num, {
    x: x + 0.15, y: y + 0.15, w: 0.45, h: 0.45, fontSize: 16, fontFace: "Arial", color: colors.navy, bold: true, align: "center", valign: "middle"
  });
  slide12.addText(step.title, {
    x: x + 0.7, y: y + 0.15, w: 2.0, h: 0.4, fontSize: 13, fontFace: "Arial", color: colors.navy, bold: true
  });
  slide12.addText(step.desc, {
    x: x + 0.15, y: y + 0.65, w: 2.6, h: 0.6, fontSize: 11, fontFace: "Arial", color: "666666"
  });

  // Arrow between steps
  if (i < workflowSteps.length - 1 && i !== 2) {
    const nextRow = Math.floor((i + 1) / 3);
    if (row === nextRow) {
      slide12.addText("→", {
        x: x + 2.9, y: y + 0.5, w: 0.2, h: 0.4, fontSize: 16, color: colors.cyan
      });
    }
  }
});

// Agentic steps explanation
slide12.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 4.35, w: 9, h: 1.0, fill: { color: colors.navy }
});
slide12.addText("Agentic Steps: Observe → Analyze → Plan → Recommend → Update", {
  x: 0.7, y: 4.5, w: 8.6, h: 0.7, fontSize: 14, fontFace: "Arial", color: colors.white, align: "center", valign: "middle"
});

// ================== SLIDE 13: Data Sources ==================
let slide13 = pres.addSlide();
slide13.background = { color: colors.lightGray };

slide13.addText("Data Sources and Daily Updates", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

slide13.addText("Data and Market Update Strategy", {
  x: 0.5, y: 0.9, w: 9, h: 0.4, fontSize: 20, fontFace: "Arial", color: colors.cyan, bold: true
});

// Data sources
slide13.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.4, w: 4.4, h: 2.8, fill: { color: colors.white }, shadow: makeShadow()
});
slide13.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.4, w: 4.4, h: 0.5, fill: { color: colors.navy }
});
slide13.addText("Data Sources", {
  x: 0.5, y: 1.4, w: 4.4, h: 0.5, fontSize: 16, fontFace: "Arial", color: colors.white, bold: true, align: "center", valign: "middle"
});

const dataSources = [
  "User-supplied financial data",
  "External market data providers",
  "Stock market data",
  "Real estate market aggregators",
  "Portfolio inputs"
];

slide13.addText(dataSources.map((s, i) => ({
  text: s,
  options: { bullet: true, breakLine: i < dataSources.length - 1 }
})), {
  x: 0.7, y: 2.0, w: 4.0, h: 2.0, fontSize: 12, fontFace: "Arial", color: "444444", paraSpaceAfter: 8
});

// Update schedule
slide13.addShape(pres.shapes.RECTANGLE, {
  x: 5.1, y: 1.4, w: 4.4, h: 2.8, fill: { color: colors.white }, shadow: makeShadow()
});
slide13.addShape(pres.shapes.RECTANGLE, {
  x: 5.1, y: 1.4, w: 4.4, h: 0.5, fill: { color: colors.cyan }
});
slide13.addText("Update Schedule", {
  x: 5.1, y: 1.4, w: 4.4, h: 0.5, fontSize: 16, fontFace: "Arial", color: colors.navy, bold: true, align: "center", valign: "middle"
});

slide13.addText([
  { text: "Daily refresh schedule", options: { bullet: true, breakLine: true } },
  { text: "Real estate: daily updates OK", options: { bullet: true, breakLine: true } },
  { text: "Recommendations refresh daily", options: { bullet: true, breakLine: true } },
  { text: "Use \"last updated\" labels", options: { bullet: true, breakLine: true } },
  { text: "Example: Updated: 2026-08-21 HKT", options: { bullet: true } }
], {
  x: 5.3, y: 2.0, w: 4.0, h: 2.0, fontSize: 12, fontFace: "Arial", color: "444444", paraSpaceAfter: 8
});

// Key message
slide13.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 4.4, w: 9, h: 0.95, fill: { color: colors.cardBg }
});
slide13.addText("Key Message: The system does not need true real-time trading speed. Daily updates are enough for portfolio and real estate planning.", {
  x: 0.7, y: 4.5, w: 8.6, h: 0.75, fontSize: 13, fontFace: "Arial", color: colors.white, valign: "middle", align: "center"
});

// ================== SLIDE 14: Compliance ==================
let slide14 = pres.addSlide();
slide14.background = { color: colors.lightGray };

slide14.addText("Compliance, Ethics, and Risk Control", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

slide14.addText("Compliance-Safe and Responsible AI Design", {
  x: 0.5, y: 0.9, w: 9, h: 0.4, fontSize: 20, fontFace: "Arial", color: colors.cyan, bold: true
});

// Compliance items
const complianceItems = [
  { title: "Educational Insights Only", desc: "No guaranteed return language" },
  { title: "Clear Disclaimers", desc: "Always state it's not regulated advice" },
  { title: "Data Freshness Labels", desc: "Show when data was last updated" },
  { title: "Explainable Reasoning", desc: "Show how AI reached conclusions" },
  { title: "User Confirmation", desc: "Confirm before major actions" },
  { title: "Risk Warnings", desc: "Alert on debt and leverage risks" }
];

complianceItems.forEach((item, i) => {
  const col = i % 3;
  const row = Math.floor(i / 3);
  const x = 0.5 + col * 3.1;
  const y = 1.4 + row * 1.15;

  slide14.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: 2.9, h: 1.0, fill: { color: colors.white }, shadow: makeShadow()
  });
  slide14.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: 0.08, h: 1.0, fill: { color: colors.cyan }
  });
  slide14.addText(item.title, {
    x: x + 0.2, y: y + 0.1, w: 2.5, h: 0.35, fontSize: 12, fontFace: "Arial", color: colors.navy, bold: true
  });
  slide14.addText(item.desc, {
    x: x + 0.2, y: y + 0.5, w: 2.5, h: 0.4, fontSize: 10, fontFace: "Arial", color: "666666"
  });
});

// Disclaimer
slide14.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 3.85, w: 9, h: 1.5, fill: { color: "FFF3E0" }, line: { color: "FF9800", pt: 1 }
});
slide14.addText("📋 Disclaimer", {
  x: 0.7, y: 3.95, w: 8.6, h: 0.35, fontSize: 14, fontFace: "Arial", color: "E65100", bold: true
});
slide14.addText("AI Pocket Advisor provides educational information based on user inputs and market data. It does not provide guaranteed investment returns or regulated financial advice. Users should consult qualified professionals before making financial decisions.", {
  x: 0.7, y: 4.35, w: 8.6, h: 0.85, fontSize: 11, fontFace: "Arial", color: "444444"
});

// ================== SLIDE 15: Business Model ==================
let slide15 = pres.addSlide();
slide15.background = { color: colors.lightGray };

slide15.addText("Business Model and Application Potential", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

slide15.addText("Business Application and Monetization Potential", {
  x: 0.5, y: 0.9, w: 9, h: 0.4, fontSize: 20, fontFace: "Arial", color: colors.cyan, bold: true
});

// Business models
const bizModels = [
  "Freemium personal finance dashboard",
  "Premium AI financial planning simulations",
  "Subscription for advanced portfolio analytics",
  "Paid real estate opportunity reports",
  "B2B white-label for banks/brokers",
  "API integration with financial institutions"
];

slide15.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.4, w: 5.5, h: 2.6, fill: { color: colors.white }, shadow: makeShadow()
});
slide15.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.4, w: 5.5, h: 0.5, fill: { color: colors.navy }
});
slide15.addText("Possible Business Models", {
  x: 0.5, y: 1.4, w: 5.5, h: 0.5, fontSize: 16, fontFace: "Arial", color: colors.white, bold: true, align: "center", valign: "middle"
});

slide15.addText(bizModels.map((m, i) => ({
  text: m,
  options: { bullet: true, breakLine: i < bizModels.length - 1 }
})), {
  x: 0.7, y: 2.0, w: 5.1, h: 1.9, fontSize: 12, fontFace: "Arial", color: "444444", paraSpaceAfter: 8
});

// Business value
slide15.addShape(pres.shapes.RECTANGLE, {
  x: 6.2, y: 1.4, w: 3.3, h: 2.6, fill: { color: colors.cardBg }
});
slide15.addText("Business Value", {
  x: 6.4, y: 1.5, w: 2.9, h: 0.35, fontSize: 14, fontFace: "Arial", color: colors.cyan, bold: true
});
slide15.addText([
  { text: "Improves customer engagement", options: { bullet: true, breakLine: true } },
  { text: "Reduces manual advisory workload", options: { bullet: true, breakLine: true } },
  { text: "Provides scalable personalization", options: { bullet: true, breakLine: true } },
  { text: "Supports financial education", options: { bullet: true, breakLine: true } },
  { text: "Creates data-driven opportunities", options: { bullet: true } }
], {
  x: 6.4, y: 1.95, w: 2.9, h: 1.9, fontSize: 11, fontFace: "Arial", color: colors.white, paraSpaceAfter: 5
});

// Value proposition
slide15.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 4.2, w: 9, h: 1.15, fill: { color: colors.navy }
});
slide15.addText("Value Proposition:", {
  x: 0.7, y: 4.3, w: 8.6, h: 0.35, fontSize: 14, fontFace: "Arial", color: colors.cyan, bold: true
});
slide15.addText("AI Pocket Advisor helps users transform personal financial data into clear, responsible, and educational wealth insights.", {
  x: 0.7, y: 4.7, w: 8.6, h: 0.55, fontSize: 13, fontFace: "Arial", color: colors.white
});

// ================== SLIDE 16: Demo Plan ==================
let slide16 = pres.addSlide();
slide16.background = { color: colors.lightGray };

slide16.addText("Demo Plan", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

slide16.addText("Website Demonstration Plan", {
  x: 0.5, y: 0.9, w: 9, h: 0.4, fontSize: 20, fontFace: "Arial", color: colors.cyan, bold: true
});

// Demo steps
const demoSteps = [
  "Homepage introduction",
  "Create account / demo profile",
  "Wealth onboarding survey",
  "Expenditure page",
  "Real estate page",
  "Stock market analysis page",
  "User portfolio page",
  "Recommendation or insight page"
];

demoSteps.forEach((step, i) => {
  const col = i % 2;
  const row = Math.floor(i / 2);
  const x = 0.5 + col * 4.7;
  const y = 1.4 + row * 0.85;

  slide16.addShape(pres.shapes.OVAL, {
    x: x, y: y + 0.1, w: 0.4, h: 0.4, fill: { color: colors.cyan }
  });
  slide16.addText(String(i + 1), {
    x: x, y: y + 0.1, w: 0.4, h: 0.4, fontSize: 14, fontFace: "Arial", color: colors.navy, bold: true, align: "center", valign: "middle"
  });
  slide16.addText(step, {
    x: x + 0.5, y: y + 0.1, w: 4.0, h: 0.4, fontSize: 13, fontFace: "Arial", color: "444444", valign: "middle"
  });
});

// Tip
slide16.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 4.85, w: 9, h: 0.5, fill: { color: colors.navy }
});
slide16.addText("💡 Tip: Prepare screenshots in case internet or deployment fails during class.", {
  x: 0.7, y: 4.85, w: 8.6, h: 0.5, fontSize: 13, fontFace: "Arial", color: colors.white, valign: "middle", align: "center"
});

// ================== SLIDE 17: Limitations ==================
let slide17 = pres.addSlide();
slide17.background = { color: colors.lightGray };

slide17.addText("Limitations and Future Improvements", {
  x: 0.5, y: 0.3, w: 9, h: 0.7, fontSize: 36, fontFace: "Arial", color: colors.navy, bold: true
});

slide17.addText("Limitations and Future Development", {
  x: 0.5, y: 0.9, w: 9, h: 0.4, fontSize: 20, fontFace: "Arial", color: colors.cyan, bold: true
});

// Current limitations
slide17.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.4, w: 4.4, h: 2.6, fill: { color: colors.white }, shadow: makeShadow()
});
slide17.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.4, w: 4.4, h: 0.5, fill: { color: "E57373" }
});
slide17.addText("Current Limitations", {
  x: 0.5, y: 1.4, w: 4.4, h: 0.5, fontSize: 15, fontFace: "Arial", color: colors.white, bold: true, align: "center", valign: "middle"
});

const limitations = [
  "Accuracy depends on user input quality",
  "Market data may be incomplete or delayed",
  "AI recommendations require compliance safeguards",
  "Real estate estimates are not exact valuations",
  "Financial outcomes cannot be guaranteed"
];

slide17.addText(limitations.map((l, i) => ({
  text: l,
  options: { bullet: true, breakLine: i < limitations.length - 1 }
})), {
  x: 0.7, y: 2.0, w: 4.0, h: 1.9, fontSize: 11, fontFace: "Arial", color: "444444", paraSpaceAfter: 6
});

// Future improvements
slide17.addShape(pres.shapes.RECTANGLE, {
  x: 5.1, y: 1.4, w: 4.4, h: 2.6, fill: { color: colors.white }, shadow: makeShadow()
});
slide17.addShape(pres.shapes.RECTANGLE, {
  x: 5.1, y: 1.4, w: 4.4, h: 0.5, fill: { color: "81C784" }
});
slide17.addText("Future Improvements", {
  x: 5.1, y: 1.4, w: 4.4, h: 0.5, fontSize: 15, fontFace: "Arial", color: colors.white, bold: true, align: "center", valign: "middle"
});

const improvements = [
  "Bank account integration",
  "Advanced stock screening",
  "HK property data API integration",
  "Tax and transaction cost modeling",
  "Scenario planning",
  "Credit score integration",
  "Human advisor review option",
  "Mobile app version",
  "Multi-language support"
];

slide17.addText(improvements.map((imp, i) => ({
  text: imp,
  options: { bullet: true, breakLine: i < improvements.length - 1 }
})), {
  x: 5.3, y: 1.95, w: 4.0, h: 1.9, fontSize: 10, fontFace: "Arial", color: "444444", paraSpaceAfter: 3
});

// ================== SLIDE 18: Conclusion ==================
let slide18 = pres.addSlide();
slide18.background = { color: colors.navy };

// Decorative top bar
slide18.addShape(pres.shapes.RECTANGLE, {
  x: 0, y: 0, w: 10, h: 0.15, fill: { color: colors.cyan }
});

slide18.addText("Conclusion", {
  x: 0.5, y: 0.8, w: 9, h: 0.7, fontSize: 40, fontFace: "Arial", color: colors.white, bold: true, align: "center"
});

// Key takeaways
const takeaways = [
  "AI Pocket Advisor applies Agentic AI to personal finance and investment planning",
  "The system connects user goals, expenditures, real estate, stocks, and portfolio data",
  "Agentic AI improves personalization, explainability, and decision support",
  "Compliance-safe design is essential in FinTech",
  "The project shows how AI can support better financial education and planning"
];

takeaways.forEach((takeaway, i) => {
  slide18.addShape(pres.shapes.RECTANGLE, {
    x: 0.8, y: 1.7 + i * 0.65, w: 8.4, h: 0.55, fill: { color: colors.cardBg }
  });
  slide18.addText(takeaway, {
    x: 1.0, y: 1.7 + i * 0.65, w: 8.0, h: 0.55, fontSize: 12, fontFace: "Arial", color: colors.white, valign: "middle"
  });
});

// Closing sentence
slide18.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 4.95, w: 9, h: 0.5, fill: { color: colors.cyan }
});
slide18.addText("AI Pocket Advisor demonstrates how Agentic AI can transform financial data into responsible, personalized, and actionable wealth insights.", {
  x: 0.7, y: 4.95, w: 8.6, h: 0.5, fontSize: 13, fontFace: "Arial", color: colors.navy, bold: true, align: "center", valign: "middle"
});

// Save
pres.writeFile({ fileName: "/Users/luyumeng/Desktop/AI_Pocket_Advisor_Presentation.pptx" })
  .then(() => console.log("✅ Presentation saved!"))
  .catch(err => console.error("Error:", err));
