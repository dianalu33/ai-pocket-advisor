'use client'

import { useEffect, useMemo, useState } from 'react'
import {
  ArrowUpRight,
  BarChart3,
  Bell,
  BookOpen,
  BrainCircuit,
  Check,
  ChevronRight,
  CircleDollarSign,
  Compass,
  Gauge,
  LayoutDashboard,
  LogOut,
  Menu,
  MessageCircle,
  Newspaper,
  Plus,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Target,
  TrendingUp,
  WalletCards,
  X,
} from 'lucide-react'

type Language = 'en' | 'yue' | 'zh'
type ChatMessage = { role: 'user' | 'assistant'; content: string }

type Profile = {
  age: number
  salary: number
  otherIncome: number
  expenses: number
  debt: number
  emergencySavings: number
  goal: string
  timeline: number
  risk: 'conservative' | 'balanced' | 'growth'
  interests: string[]
}

type Recommendation = {
  profileLabel: string
  allocation: { name: string; value: number; color: string; reason: string }[]
  monthlyContribution: number
  emergencyTarget: number
  emergencyGap: number
  rationale: string[]
  risks: string[]
  actions: string[]
  ideas: string[]
}

type Market = {
  pulse: { name: string; value: string; change: string; tone: 'up' | 'down' | 'flat' }[]
  assets: { name: string; symbol: string; price: string; change: string; tone: 'up' | 'down' }[]
  trending: string[]
  news: { title: string; source: string; time: string; tag: string }[]
}

const defaultProfile: Profile = {
  age: 29,
  salary: 72000,
  otherIncome: 6000,
  expenses: 3400,
  debt: 12000,
  emergencySavings: 8500,
  goal: 'Build long-term wealth',
  timeline: 10,
  risk: 'balanced',
  interests: ['Index funds', 'Crypto', 'HYSA'],
}

const fallbackMarket: Market = {
  pulse: [
    { name: 'S&P 500', value: '5,842.11', change: '+0.68%', tone: 'up' },
    { name: 'NASDAQ', value: '18,912.44', change: '+1.12%', tone: 'up' },
    { name: 'Bitcoin', value: '$104,260', change: '+2.41%', tone: 'up' },
    { name: '10Y Treasury', value: '4.21%', change: '-0.04%', tone: 'down' },
  ],
  assets: [
    { name: 'Bitcoin', symbol: 'BTC', price: '$104,260', change: '+2.41%', tone: 'up' },
    { name: 'Ethereum', symbol: 'ETH', price: '$3,812', change: '+1.88%', tone: 'up' },
    { name: 'S&P 500 ETF', symbol: 'VOO', price: '$538.22', change: '+0.68%', tone: 'up' },
    { name: 'US Bond ETF', symbol: 'BND', price: '$73.10', change: '-0.12%', tone: 'down' },
  ],
  trending: ['AI infrastructure', 'Tokenized treasuries', 'Quality dividends', 'Emerging markets'],
  news: [
    { title: 'Markets weigh cooling inflation against resilient growth', source: 'Market Brief', time: '18 min ago', tag: 'Macro' },
    { title: 'Bitcoin liquidity improves as institutional demand returns', source: 'Digital Assets Daily', time: '42 min ago', tag: 'Crypto' },
    { title: 'Treasury yields dip as investors rotate toward quality', source: 'The Financial Wire', time: '1 hr ago', tag: 'Bonds' },
  ],
}

const interestOptions = ['Index funds', 'Mutual funds', 'REITs', 'Crypto', 'HYSA', 'Bonds']

const uiCopy = {
  en: { assistant: 'AI Pocket Advisor', ask: 'Ask your immediate assistant', overview: 'Overview', plan: 'My plan', market: 'Market', learn: 'Learn', logout: 'Log out', greeting: 'let’s make progress.', welcome: 'Welcome to AI Pocket Advisor', language: 'Language' },
  yue: { assistant: 'AI Pocket Advisor', ask: '問下你嘅即時助手', overview: '概覽', plan: '我嘅計劃', market: '市場', learn: '學習', logout: '登出', greeting: '一齊向前行。', welcome: '歡迎使用 AI Pocket Advisor', language: '語言' },
  zh: { assistant: 'AI Pocket Advisor', ask: '询问你的即时助手', overview: '概览', plan: '我的计划', market: '市场', learn: '学习', logout: '退出登录', greeting: '一起向前进。', welcome: '欢迎使用 AI Pocket Advisor', language: '语言' },
} as const

function money(value: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(value)
}

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="brand-lockup">
      <img src="/aurum-ai-logo.svg" alt="AI Pocket Advisor" className={compact ? 'brand-mark compact' : 'brand-mark'} />
      {!compact && <div><div className="brand-name">AI Pocket</div><div className="brand-subtitle">advisor</div></div>}
    </div>
  )
}

function AuthScreen({ onAuth, language, onLanguageChange }: { onAuth: (name: string) => void; language: Language; onLanguageChange: (language: Language) => void }) {
  const [mode, setMode] = useState<'login' | 'register'>('register')
  const [name, setName] = useState('Alex Morgan')
  const [email, setEmail] = useState('alex@example.com')
  const [password, setPassword] = useState('aurum-demo')
  const [error, setError] = useState('')

  function submit(event: React.FormEvent) {
    event.preventDefault()
    if (!name.trim() || !email.includes('@') || password.length < 6) {
      setError('Enter your name, a valid email, and a password with 6+ characters.')
      return
    }
    onAuth(name.trim())
  }

  return (
    <main className="auth-page">
      <div className="auth-grid" />
      <header className="auth-header"><Logo /><div className="auth-header-actions"><LanguageSelect language={language} onChange={onLanguageChange} /><span className="secure-pill"><ShieldCheck size={14} /> Your data stays yours</span></div></header>
      <section className="auth-content">
        <div className="auth-story">
          <div className="eyebrow"><Sparkles size={15} /> Intelligent wealth, made personal</div>
          <h1>Make your money<br /><em>move with intention.</em></h1>
          <p>AI Pocket Advisor turns your real-world financial picture into a calm, clear plan for what comes next — from emergency savings to long-term investing.</p>
          <div className="story-points"><span><Check size={16} /> No bank connection required</span><span><Check size={16} /> Built on transparent logic</span><span><Check size={16} /> Always educational, never a promise</span></div>
        </div>
        <div className="auth-card">
          <div className="auth-card-top"><div><p className="overline">Welcome to AI Pocket Advisor</p><h2>{mode === 'register' ? 'Build your wealth view' : 'Welcome back'}</h2></div><div className="auth-badge"><BrainCircuit size={19} /></div></div>
          <div className="auth-tabs"><button className={mode === 'register' ? 'active' : ''} onClick={() => setMode('register')}>Create account</button><button className={mode === 'login' ? 'active' : ''} onClick={() => setMode('login')}>Log in</button></div>
          <form onSubmit={submit}>
            {mode === 'register' && <label>Full name<input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" /></label>}
            <label>Email address<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" /></label>
            <label>Password<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 6 characters" /></label>
            {error && <p className="form-error">{error}</p>}
            <button className="primary-button" type="submit">{mode === 'register' ? 'Start my wealth view' : 'Log in to AI Pocket Advisor'} <ArrowUpRight size={17} /></button>
          </form>
          <button className="demo-button" onClick={() => onAuth('Alex Morgan')}><Compass size={16} /> Explore with demo profile</button>
          <p className="legal-copy">By continuing, you agree that AI Pocket Advisor provides educational information, not individualized financial advice.</p>
        </div>
      </section>
      <footer className="auth-footer"><span>© 2026 AI Pocket Advisor</span><span>Privacy</span><span>How it works</span><span>Built for thoughtful investors</span></footer>
    </main>
  )
}

function ProfileForm({ profile, setProfile, onGenerate, loading }: { profile: Profile; setProfile: (profile: Profile) => void; onGenerate: () => void; loading: boolean }) {
  function update(key: keyof Profile, value: string | number) { setProfile({ ...profile, [key]: value }) }
  function toggleInterest(item: string) { setProfile({ ...profile, interests: profile.interests.includes(item) ? profile.interests.filter((x) => x !== item) : [...profile.interests, item] }) }
  return (
    <section className="profile-panel panel">
      <div className="section-heading"><div><p className="overline">Your financial snapshot</p><h2>Give AI Pocket Advisor the full picture</h2><p>More context means advice that feels less generic.</p></div><div className="step-count">01 <span>/ 01</span></div></div>
      <div className="form-grid">
        <label>Age<input type="number" value={profile.age} onChange={(e) => update('age', Number(e.target.value))} /></label>
        <label>Annual salary<input type="number" value={profile.salary} onChange={(e) => update('salary', Number(e.target.value))} /></label>
        <label>Other annual income<input type="number" value={profile.otherIncome} onChange={(e) => update('otherIncome', Number(e.target.value))} /></label>
        <label>Monthly expenses<input type="number" value={profile.expenses} onChange={(e) => update('expenses', Number(e.target.value))} /></label>
        <label>Total high-interest debt<input type="number" value={profile.debt} onChange={(e) => update('debt', Number(e.target.value))} /></label>
        <label>Emergency savings<input type="number" value={profile.emergencySavings} onChange={(e) => update('emergencySavings', Number(e.target.value))} /></label>
        <label className="span-two">Primary money goal<select value={profile.goal} onChange={(e) => update('goal', e.target.value)}><option>Build long-term wealth</option><option>Buy a home</option><option>Fund education</option><option>Reach financial independence</option><option>Protect my family</option></select></label>
        <label>Goal timeline<select value={profile.timeline} onChange={(e) => update('timeline', Number(e.target.value))}><option value={2}>1–3 years</option><option value={5}>3–7 years</option><option value={10}>7–15 years</option><option value={20}>15+ years</option></select></label>
      </div>
      <div className="field-group"><span className="field-label">How much market movement can you live with?</span><div className="risk-options">{(['conservative', 'balanced', 'growth'] as const).map((risk) => <button key={risk} className={profile.risk === risk ? 'selected' : ''} onClick={() => update('risk', risk)}><span className={`risk-dot ${risk}`} /> <strong>{risk[0].toUpperCase() + risk.slice(1)}</strong><small>{risk === 'conservative' ? 'Protect first' : risk === 'balanced' ? 'Steady compounding' : 'Maximize upside'}</small>{profile.risk === risk && <Check size={14} />}</button>)}</div></div>
      <div className="field-group"><span className="field-label">What are you curious about?</span><div className="interest-list">{interestOptions.map((item) => <button key={item} className={profile.interests.includes(item) ? 'interest selected' : 'interest'} onClick={() => toggleInterest(item)}>{profile.interests.includes(item) ? <Check size={13} /> : <Plus size={13} />}{item}</button>)}</div></div>
      <button className="primary-button wide" onClick={onGenerate} disabled={loading}>{loading ? <><RefreshCw size={16} className="spin" /> Thinking through your picture...</> : <>Generate my plan <ChevronRight size={17} /></>}</button>
    </section>
  )
}

function RecommendationCard({ recommendation, onEdit }: { recommendation: Recommendation; onEdit: () => void }) {
  return <section className="recommendation-panel panel"><div className="section-heading"><div><p className="overline aqua">Your AI Pocket Advisor read</p><h2>A plan with room to breathe.</h2><p>Based on your {recommendation.profileLabel.toLowerCase()} profile and stated priorities.</p></div><button className="text-button" onClick={onEdit}>Edit snapshot <ArrowUpRight size={15} /></button></div><div className="recommendation-grid"><div className="allocation"><div className="allocation-ring"><div><strong>{recommendation.allocation.find((item) => item.name === 'Index funds')?.value ?? 0}%</strong><span>core growth</span></div></div><div className="allocation-legend">{recommendation.allocation.map((item) => <div key={item.name}><span className="legend-dot" style={{ backgroundColor: `var(${item.color})` }} /><div><strong>{item.name}</strong><span>{item.value}% · {item.reason}</span></div></div>)}</div></div><div className="plan-summary"><div className="summary-number"><span>Suggested monthly contribution</span><strong>{money(recommendation.monthlyContribution)}</strong><small>about {Math.round(recommendation.monthlyContribution / 4)} per week</small></div><div className="summary-number"><span>Emergency fund target</span><strong>{money(recommendation.emergencyTarget)}</strong><small className={recommendation.emergencyGap > 0 ? 'warning' : 'positive'}>{recommendation.emergencyGap > 0 ? `${money(recommendation.emergencyGap)} to go` : 'You are on track'}</small></div><div className="rationale"><h3>Why this mix</h3>{recommendation.rationale.map((item) => <p key={item}><Check size={14} />{item}</p>)}</div></div></div><div className="action-strip"><div><Target size={18} /><div><strong>Your next best move</strong><span>{recommendation.actions[0]}</span></div></div><button className="small-button">See action plan <ChevronRight size={15} /></button></div><details className="more-details"><summary>See risks and asset ideas</summary><div className="details-grid"><div><h3>Watch-outs</h3>{recommendation.risks.map((item) => <p key={item}>• {item}</p>)}</div><div><h3>Explore first</h3>{recommendation.ideas.map((item) => <p key={item}>• {item}</p>)}</div></div></details><p className="disclaimer">AI Pocket Advisor is an educational planning tool. Allocation examples are illustrative and are not a recommendation to buy or sell any security.</p></section>
}

function MarketPanel({ market, onRefresh, refreshing }: { market: Market; onRefresh: () => void; refreshing: boolean }) {
  return <><section className="market-panel panel"><div className="section-heading compact-heading"><div><p className="overline">Market pulse</p><h2>Stay curious, not reactive.</h2></div><button className="icon-button" aria-label="Refresh market data" onClick={onRefresh}><RefreshCw size={16} className={refreshing ? 'spin' : ''} /></button></div><div className="pulse-row">{market.pulse.map((item) => <div className="pulse-card" key={item.name}><span>{item.name}</span><strong>{item.value}</strong><small className={item.tone}>{item.change}</small><div className="sparkline"><span /><span /><span /><span /><span /><span /></div></div>)}</div></section><div className="lower-grid"><section className="table-panel panel"><div className="section-heading compact-heading"><div><p className="overline">Watchlist</p><h2>Assets in motion</h2></div><button className="text-button">View all <ArrowUpRight size={15} /></button></div><div className="asset-table">{market.assets.map((asset) => <div className="asset-row" key={asset.symbol}><div className="asset-icon">{asset.symbol.slice(0, 1)}</div><div><strong>{asset.name}</strong><span>{asset.symbol}</span></div><strong className="asset-price">{asset.price}</strong><span className={asset.tone}>{asset.change}</span><ChevronRight size={15} /></div>)}</div></section><section className="news-panel panel"><div className="section-heading compact-heading"><div><p className="overline">Signal, not noise</p><h2>Market brief</h2></div><Newspaper size={18} className="muted-icon" /></div><div className="news-list">{market.news.map((item) => <article key={item.title}><div className="news-meta"><span>{item.tag}</span><time>{item.time}</time></div><h3>{item.title}</h3><p>{item.source}</p></article>)}</div></section></div><section className="trend-panel panel"><div><p className="overline">Themes to explore</p><h2>What is moving the conversation</h2></div><div className="trend-list">{market.trending.map((trend) => <span key={trend}><TrendingUp size={14} />{trend}</span>)}</div></section></>
}

function LanguageSelect({ language, onChange }: { language: Language; onChange: (language: Language) => void }) {
  return <label className="language-select"><span className="sr-only">Language</span><select aria-label="Language" value={language} onChange={(event) => onChange(event.target.value as Language)}><option value="en">English</option><option value="yue">廣東話</option><option value="zh">普通话</option></select></label>
}

function Assistant({ language, profile, recommendation, market }: { language: Language; profile: Profile; recommendation: Recommendation | null; market: Market }) {
  const [open, setOpen] = useState(false)
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const t = uiCopy[language]
  const suggestions = language === 'en' ? ['Explain my allocation', 'How much emergency savings do I need?', 'Should I add more crypto?'] : language === 'yue' ? ['解釋我嘅資產配置', '我需要幾多應急儲蓄？', '我應唔應該增加加密貨幣？'] : ['解释我的资产配置', '我需要多少应急储蓄？', '我应该增加加密货币吗？']
  async function send(text = input) { if (!text.trim() || sending) return; const userMessage = text.trim(); setInput(''); setMessages((current) => [...current, { role: 'user', content: userMessage }]); setSending(true); try { const response = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: userMessage, language, profile, recommendation, market }) }); const data = await response.json(); setMessages((current) => [...current, { role: 'assistant', content: data.message }]) } catch { setMessages((current) => [...current, { role: 'assistant', content: language === 'yue' ? '而家未能連接助手，請稍後再試。' : language === 'zh' ? '暂时无法连接助手，请稍后再试。' : 'The assistant is unavailable right now. Please try again.' }]) } finally { setSending(false) } }
  return <><button className="assistant-launcher" aria-label={t.assistant} onClick={() => setOpen(true)}><MessageCircle size={19} /><span>{t.assistant}</span><i /></button>{open && <section className="assistant-panel" aria-label={t.assistant}><header><div><strong>{t.assistant}</strong><span>{t.ask}</span></div><button aria-label="Close assistant" onClick={() => setOpen(false)}><X size={17} /></button></header><div className="assistant-messages">{messages.length === 0 && <div className="assistant-welcome"><Sparkles size={18} /><p>{language === 'yue' ? '你好！我可以幫你睇下個人化投資計劃。' : language === 'zh' ? '你好！我可以帮你看看个性化投资计划。' : 'Hi! I can help you understand your personalized investment plan.'}</p></div>}{messages.map((message, index) => <div key={`${message.role}-${index}`} className={`chat-message ${message.role}`}>{message.content}</div>)}{sending && <div className="chat-message assistant">...</div>}</div><div className="assistant-suggestions">{suggestions.map((suggestion) => <button key={suggestion} onClick={() => send(suggestion)}>{suggestion}</button>)}</div><form onSubmit={(event) => { event.preventDefault(); void send() }}><input value={input} onChange={(event) => setInput(event.target.value)} placeholder={language === 'yue' ? '輸入問題…' : language === 'zh' ? '输入问题…' : 'Ask a question…'} /><button aria-label="Send message" type="submit"><ArrowUpRight size={17} /></button></form></section>}</>
}

export function AurumMvp() {
  const [user, setUser] = useState<string | null>(null)
  const [language, setLanguage] = useState<Language>('en')
  const t = uiCopy[language]
  const [profile, setProfile] = useState<Profile>(defaultProfile)
  const [recommendation, setRecommendation] = useState<Recommendation | null>(null)
  const [market, setMarket] = useState<Market>(fallbackMarket)
  const [loading, setLoading] = useState(false)
  const [refreshing, setRefreshing] = useState(false)
  const [mobileNav, setMobileNav] = useState(false)

  useEffect(() => { const saved = window.localStorage.getItem('aurum-demo-user'); const savedProfile = window.localStorage.getItem('aurum-demo-profile'); const savedLanguage = window.localStorage.getItem('ai-pocket-language') as Language | null; if (saved) setUser(saved); if (savedProfile) setProfile(JSON.parse(savedProfile)); if (savedLanguage === 'en' || savedLanguage === 'yue' || savedLanguage === 'zh') setLanguage(savedLanguage); fetch('/api/market').then((res) => res.json()).then((data) => data?.news && setMarket(data)).catch(() => undefined) }, [])
  useEffect(() => { if (user) window.localStorage.setItem('aurum-demo-profile', JSON.stringify(profile)) }, [profile, user])
  function changeLanguage(next: Language) { setLanguage(next); window.localStorage.setItem('ai-pocket-language', next) }
  function auth(name: string) { setUser(name); window.localStorage.setItem('aurum-demo-user', name) }
  async function generate() { setLoading(true); try { const response = await fetch('/api/recommend', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(profile) }); const data = await response.json(); if (response.ok) setRecommendation(data) } finally { setLoading(false) } }
  async function refreshMarket() { setRefreshing(true); try { const response = await fetch('/api/market?refresh=1'); const data = await response.json(); if (data?.news) setMarket(data) } finally { setRefreshing(false) } }
  if (!user) return <AuthScreen onAuth={auth} language={language} onLanguageChange={changeLanguage} />
  return <main className="app-shell"><aside className={mobileNav ? 'sidebar open' : 'sidebar'}><div className="sidebar-top"><Logo /><button className="close-nav" onClick={() => setMobileNav(false)}><X size={18} /></button></div><nav><p className="nav-label">Workspace</p><button className="nav-item active"><LayoutDashboard size={17} /> {t.overview}</button><button className="nav-item"><WalletCards size={17} /> {t.plan}</button><button className="nav-item"><BarChart3 size={17} /> {t.market}</button><button className="nav-item"><BookOpen size={17} /> {t.learn}</button><p className="nav-label spaced">Your progress</p><div className="progress-card"><div className="progress-icon"><Gauge size={16} /></div><strong>Investor profile</strong><span>80% complete</span><div className="progress-line"><i /></div></div></nav><div className="sidebar-bottom"><button className="nav-item"><Bell size={17} /> Alerts <span className="notification-dot" /></button><button className="profile-mini"><span className="avatar">{user.slice(0, 1)}</span><span><strong>{user}</strong><small>Free account</small></span><ChevronRight size={15} /></button><button className="logout" onClick={() => { setUser(null); setRecommendation(null); window.localStorage.removeItem('aurum-demo-user') }}><LogOut size={15} /> Log out</button></div></aside><div className="main-content"><header className="topbar"><button className="mobile-menu" onClick={() => setMobileNav(true)}><Menu size={20} /></button><div><p className="topbar-kicker">Wednesday, August 5, 2026</p><h1>Good morning, {user.split(' ')[0]} <span>—</span> let&apos;s make progress.</h1></div><div className="topbar-actions"><LanguageSelect language={language} onChange={changeLanguage} /><button className="icon-button"><Bell size={17} /><i /></button><div className="avatar large">{user.slice(0, 1)}</div></div></header><Assistant language={language} profile={profile} recommendation={recommendation} market={market} /><div className="ticker"><span className="live-dot" /> Live market snapshot <div className="ticker-track">{market.pulse.map((item) => <span key={item.name}><strong>{item.name}</strong> {item.value} <em className={item.tone}>{item.change}</em></span>)}</div></div><div className="content-wrap"><section className="welcome-block"><div><p className="eyebrow"><Sparkles size={14} /> Your personal money cockpit</p><h2>Clarity compounds.</h2><p>Here&apos;s the signal from your financial picture, plus a few places to focus next.</p></div><div className="date-chip"><CircleDollarSign size={16} /> Updated just now</div></section>{!recommendation ? <ProfileForm profile={profile} setProfile={setProfile} onGenerate={generate} loading={loading} /> : <><RecommendationCard recommendation={recommendation} onEdit={() => setRecommendation(null)} /><MarketPanel market={market} onRefresh={refreshMarket} refreshing={refreshing} /></>}</div></div></main>
}
